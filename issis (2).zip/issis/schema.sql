-- ============================================================
-- SCRIPT DDL - LOGITECH EXPRESS (BANCO DE DADOS NORMALIZADO 3NF)
-- ============================================================

-- Drop de tabelas caso já existam (ordem inversa de dependência)
DROP TABLE IF EXISTS coletas CASCADE;
DROP TABLE IF EXISTS veiculos CASCADE;
DROP TABLE IF EXISTS frota_ferramentas CASCADE;
DROP TABLE IF EXISTS ferramentas CASCADE;
DROP TABLE IF EXISTS frotas CASCADE;
DROP TABLE IF EXISTS motoristas CASCADE;

-- 1. TABELA DE MOTORISTAS
-- Soluciona a duplicidade de cadastros com restrições UNIQUE nos documentos
CREATE TABLE motoristas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    nif_cpf VARCHAR(20) UNIQUE NOT NULL,
    cnh VARCHAR(20) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo', 'suspenso')),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. TABELA DE FROTAS
CREATE TABLE frotas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    regiao VARCHAR(100) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. TABELA DE FERRAMENTAS / EQUIPAMENTOS
-- Isola os itens individualmente (elimina a string separada por vírgulas)
CREATE TABLE ferramentas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT
);

-- 4. TABELA ASSOCIATIVA (N:M) - FROTA E FERRAMENTAS
-- Resolve o problema de armazenamento em célula única (1FN / 3NF)
CREATE TABLE frota_ferramentas (
    frota_id INT REFERENCES frotas(id) ON DELETE CASCADE,
    ferramenta_id INT REFERENCES ferramentas(id) ON DELETE CASCADE,
    quantidade INT DEFAULT 1 CHECK (quantidade > 0),
    PRIMARY KEY (frota_id, ferramenta_id)
);

-- 5. TABELA DE VEÍCULOS
CREATE TABLE veiculos (
    id SERIAL PRIMARY KEY,
    matricula VARCHAR(20) UNIQUE NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    frota_id INT REFERENCES frotas(id) ON DELETE SET NULL,
    status VARCHAR(20) DEFAULT 'disponivel' CHECK (status IN ('disponivel', 'em_manutencao', 'em_rota'))
);

-- 6. TABELA DE COLETAS E ENTREGAS
CREATE TABLE coletas (
    id SERIAL PRIMARY KEY,
    motorista_id INT REFERENCES motoristas(id) ON DELETE RESTRICT,
    veiculo_id INT REFERENCES veiculos(id) ON DELETE RESTRICT,
    endereco_origem TEXT NOT NULL,
    endereco_destino TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'em_transito', 'concluida', 'cancelada')),
    data_agendamento TIMESTAMP NOT NULL,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para otimização de consultas frequentes
CREATE INDEX idx_motoristas_cpf ON motoristas(nif_cpf);
CREATE INDEX idx_coletas_motorista ON coletas(motorista_id);
CREATE INDEX idx_coletas_status ON coletas(status);