-- Tabela de Motoristas (com restrições contra duplicidade)
CREATE TABLE motoristas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    nif_cpf VARCHAR(20) UNIQUE NOT NULL,
    cnh VARCHAR(20) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'ativo',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Frotas
CREATE TABLE frotas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    regiao VARCHAR(100) NOT NULL
);

-- Tabela Atómica de Ferramentas e Equipamentos
CREATE TABLE ferramentas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT
);

-- Tabela Associativa N:M (Saneamento do texto separado por vírgulas)
CREATE TABLE frota_ferramentas (
    frota_id INT REFERENCES frotas(id) ON DELETE CASCADE,
    ferramenta_id INT REFERENCES ferramentas(id) ON DELETE CASCADE,
    quantidade INT DEFAULT 1,
    PRIMARY KEY (frota_id, ferramenta_id)
);

-- Tabela de Veículos
CREATE TABLE veiculos (
    id SERIAL PRIMARY KEY,
    matricula VARCHAR(20) UNIQUE NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    frota_id INT REFERENCES frotas(id),
    status VARCHAR(20) DEFAULT 'disponivel'
);

-- Tabela de Coletas / Entregas
CREATE TABLE coletas (
    id SERIAL PRIMARY KEY,
    motorista_id INT REFERENCES motoristas(id),
    veiculo_id INT REFERENCES veiculos(id),
    endereco_origem TEXT NOT NULL,
    endereco_destino TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pendente',
    data_agendamento TIMESTAMP NOT NULL,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);