# 🚛 LogiTech Express - Back-End Architecture & API Specifications

![Status](https://img.shields.io/badge/Status-Engatilhado%20para%20Testes-blue)
![Architecture](https://img.shields.io/badge/Arquitetura-Clean%20%2F%20MVC%20%2B%20Repository-green)

Repositório oficial com a reestruturação arquitetural, saneamento de dados e esqueleto do sistema Back-End da **LogiTech Express**[cite: 1, 4].

---

## 📌 1. Diagnóstico e Arquitetura Sugerida

### Problemas do Sistema Legado Sanados:
1. **Desperdício Financeiro e Fraudes**: Eliminação de motoristas duplicados e remoção de listas de ferramentas armazenadas em formato de texto separado por vírgula em célula única.
2. **Gargalo no Back-End**: Separação rigorosa de responsabilidades em camadas desacopladas[cite: 1, 2].
3. **Insegurança Crítica**: Isolamento de chaves e senhas do código-fonte através do uso de `.env` e `.gitignore`[cite: 1, 2].

### Camadas da Aplicação:
* **`src/routes` & `src/controllers`**: Validação de requisições e respostas HTTP.
* **`src/services`**: Regras de negócio operacionais e lógica do ecossistema.
* **`src/repositories`**: Camada de abstração e acesso à base de dados PostgreSQL[cite: 2].
* **`src/models`**: Entidades puras do domínio.

---

## 📊 2. Diagrama Entidade-Relacionamento (DER)

```mermaid
erDiagram
    MOTORISTAS ||--o{ COLETAS : realiza
    FROTAS ||--o{ VEICULOS : possui
    VEICULOS ||--o{ COLETAS : alocado
    FROTAS ||--|{ FROTA_FERRAMENTAS : contem
    FERRAMENTAS ||--|{ FROTA_FERRAMENTAS : pertence

    MOTORISTAS {
        int id PK
        string nome
        string nif_cpf UK
        string cnh UK
        string email UK
        string status
    }

    FROTAS {
        int id PK
        string nome
        string regiao
    }

    FERRAMENTAS {
        int id PK
        string nome
        string descricao
    }

    FROTA_FERRAMENTAS {
        int frota_id FK
        int ferramenta_id FK
        int quantidade
    }

    VEICULOS {
        int id PK
        string matricula UK
        string modelo
        int frota_id FK
        string status
    }

    COLETAS {
        int id PK
        int motorista_id FK
        int veiculo_id FK
        string endereco_origem
        string endereco_destino
        string status
        timestamp data_agendamento
    }