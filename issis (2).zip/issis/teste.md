# Plano de Testes Documental - LogiTech Express

| ID | Cenário de Teste | Camada Alvo | Tipo de Teste | Resultado Esperado |
|---|---|---|---|---|
| CT01 | Cadastro de motorista com CPF/CNH duplicado | Controller / BD | Integração | Erro 409 Conflict[cite: 1, 4]. |
| CT02 | Atualização de status sem Token JWT | Middleware | Segurança | Erro 401 Unauthorized[cite: 2, 4]. |
| CT03 | Associação N:M de ferramentas à frota | Repository | Unitário | Sucesso na tabela `frota_ferramentas`[cite: 1, 4]. |
| CT04 | Requisição com JSON malformado | Middleware | Validação | Erro 400 Bad Request padronizado[cite: 2, 4]. |