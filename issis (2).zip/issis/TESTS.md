# 🧪 Plano de Testes Documental - LogiTech Express

Este documento estabelece a matriz detalhada de cenários de testes, validações e comportamentos esperados para o Back-End da LogiTech Express, servindo de especificação obrigatória para a próxima etapa de automação e integração.

## 📋 Matriz de Cenários de Teste

| ID | Cenário de Teste | Camada Alvo | Tipo de Teste | Dados de Entrada | Comportamento Esperado | Código HTTP |
|---|---|---|---|---|---|---|
| **CT01** | Cadastro de motorista com NIF/CPF ou CNH já existente | Controller / BD | Integração | JSON com CPF ou CNH repetido | Recusa do cadastro e mensagem de conflito explícita[cite: 1, 4] | `409 Conflict` |
| **CT02** | Requisição a rotas protegidas sem Token JWT | Middleware | Segurança | Requisição sem cabeçalho `Authorization` | Rejeição imediata do acesso por falta de autenticação | `401 Unauthorized` |
| **CT03** | Associação N:M de ferramentas à frota | Repository / BD | Unitário | `frota_id: 1`, `ferramenta_id: 3` | Gravação correta dos registos atômicos na tabela associativa[cite: 1, 4] | `201 Created` |
| **CT04** | Envio de Payload JSON com campos obrigatórios ausentes | Middleware | Validação | JSON faltando `enderecoOrigem` | Retorno da estrutura de erro padronizada detalhando o campo | `400 Bad Request` |
| **CT05** | Leitura segura de credenciais sensíveis | Config / Servidor | Segurança | Chamada à aplicação com `.env` | Conexão com o banco sem expor senhas/tokens no código-fonte | N/A |
| **CT06** | Atualização de status de coleta para valor inválido | Controller / Service | Regra de Negócio | Status: `"finalizado_com_sucesso"` | Rejeição da transição por não pertencer ao `CHECK` do banco | `422 Unprocessable` |
| **CT07** | Listagem de coletas filtrada por motorista existente | Service / Repository | Integração | `GET /api/v1/coletas/motorista/1` | Array de coletas vinculado estritamente ao ID fornecido | `200 OK` |
| **CT08** | Tentativa de alocar veículo que está em manutenção | Service | Regra de Negócio | `veiculoId` com status `'em_manutencao'` | Bloqueio do agendamento informando indisponibilidade | `400 Bad Request` |

## 🛠️ Validação e Regras de Erro Padronizadas

Todas as falhas tratadas pela aplicação devem retornar o seguinte padrão de resposta JSON para consumo seguro no Front-End:

```json
{
  "sucesso": false,
  "erro": {
    "codigo": "NOME_DO_ERRO",
    "mensagem": "Descrição clara do erro sem expor dados internos do servidor."
  }
}