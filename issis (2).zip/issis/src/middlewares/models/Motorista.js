/**
 * Abstração da Entidade Motorista
 */
class Motorista {
    constructor({ id, nome, nif_cpf, cnh, telefone, email, status }) {
        this.id = id;
        this.nome = nome;
        this.nif_cpf = nif_cpf;
        this.cnh = cnh;
        this.telefone = telefone;
        this.email = email;
        this.status = status || 'ativo';
    }
}

module.exports = Motorista;