/**
 * Abstração da Entidade Coleta
 */
class Coleta {
    constructor({ id, motoristaId, veiculoId, enderecoOrigem, enderecoDestino, status }) {
        this.id = id;
        this.motoristaId = motoristaId;
        this.veiculoId = veiculoId;
        this.enderecoOrigem = enderecoOrigem;
        this.enderecoDestino = enderecoDestino;
        this.status = status || 'pendente';
    }
}

module.exports = Coleta;