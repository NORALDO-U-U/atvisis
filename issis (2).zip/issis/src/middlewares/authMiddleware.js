const jwt = require('jsonwebtoken');

/**
 * Middleware para validar o token JWT enviado no cabeçalho Authorization
 */
module.exports = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        return res.status(401).json({ sucesso: false, mensagem: 'Token de acesso não fornecido.' });
    }

    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.usuario = decoded;
        return next();
    } catch (err) {
        return res.status(401).json({ sucesso: false, mensagem: 'Token inválido ou expirado.' });
    }
};