/**
 * Middleware centralizado de erros para evitar mensagens genéricas sem contexto
 */
module.exports = (err, req, res, next) => {
    console.error('[ERRO INTERNO]:', err.stack);
    
    return res.status(err.status || 500).json({
        sucesso: false,
        erro: {
            codigo: err.code || 'INTERNAL_SERVER_ERROR',
            mensagem: err.message || 'Ocorreu um erro interno no servidor.'
        }
    });
};