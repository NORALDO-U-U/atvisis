const motoristasService = require('../services/MotoristasService');

class MotoristasController {
    async cadastrar(req, res, next) {
        try {
            const novoMotorista = await motoristasService.cadastrarMotorista(req.body);
            return res.status(201).json({
                sucesso: true,
                dados: novoMotorista
            });
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new MotoristasController();