const coletasService = require('../services/ColetasService');

class ColetasController {
    async criarColeta(req, res, next) {
        try {
            const novaColeta = await coletasService.criarAgendamento(req.body);
            return res.status(201).json({
                sucesso: true,
                mensagem: "Coleta agendada com sucesso.",
                dados: novaColeta
            });
        } catch (error) {
            next(error);
        }
    }

    async listarPorMotorista(req, res, next) {
        try {
            const coletas = await coletasService.buscarMinhasColetas(req.params.id);
            return res.status(200).json({ sucesso: true, dados: coletas });
        } catch (error) {
            next(error);
        }
    }

    async atualizarStatus(req, res, next) {
        // Esqueleto preparado para atualização na próxima etapa
        return res.status(200).json({ sucesso: true, mensagem: "Status atualizado." });
    }
}

module.exports = new ColetasController();