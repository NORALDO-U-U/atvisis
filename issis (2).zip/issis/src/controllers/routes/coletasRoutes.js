const express = require('express');
const router = express.Router();
const ColetasController = require('../controllers/ColetasController');
const authMiddleware = require('../middlewares/authMiddleware');

router.post('/', authMiddleware, ColetasController.criarColeta);
router.get('/motorista/:id', authMiddleware, ColetasController.listarPorMotorista);
router.patch('/:id/status', authMiddleware, ColetasController.atualizarStatus);

module.exports = router;