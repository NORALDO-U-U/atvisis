const express = require('express');
const router = express.Router();

const motoristasRoutes = require('./motoristasRoutes');
const coletasRoutes = require('./coletasRoutes');

router.use('/motoristas', motoristasRoutes);
router.use('/coletas', coletasRoutes);

module.exports = router;