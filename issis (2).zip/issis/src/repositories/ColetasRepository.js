const db = require('../config/database');

class ColetasRepository {
    async criar(coletaData) {
        const query = `
            INSERT INTO coletas (motorista_id, veiculo_id, endereco_origem, endereco_destino, data_agendamento)
            VALUES ($1, $2, $3, $4, $5) RETURNING *
        `;
        const values = [
            coletaData.motoristaId, 
            coletaData.veiculoId, 
            coletaData.enderecoOrigem, 
            coletaData.enderecoDestino, 
            coletaData.dataAgendamento
        ];
        const { rows } = await db.query(query, values);
        return rows[0];
    }

    async listarPorMotorista(motoristaId) {
        const query = 'SELECT * FROM coletas WHERE motorista_id = $1';
        const { rows } = await db.query(query, [motoristaId]);
        return rows;
    }
}

module.exports = new ColetasRepository();