const coletasRepository = require('../repositories/ColetasRepository');

class ColetasService {
    async criarAgendamento(dados) {
        // Lógica de agendamento de rotas e atribuição
        return await coletasRepository.criar(dados);
    }

    async buscarMinhasColetas(motoristaId) {
        return await coletasRepository.listarPorMotorista(motoristaId);
    }
}

module.exports = new ColetasService();