const motoristasRepository = require('../repositories/MotoristasRepository');

class MotoristasService {
    async cadastrarMotorista(dados) {
        // Regra de negócio: impede duplicação
        const existe = await motoristasRepository.buscarPorCpfOuCnh(dados.nif_cpf, dados.cnh);
        if (existe) {
            const erro = new Error('Motorista já cadastrado com este documento.');
            erro.status = 409;
            throw erro;
        }
        return await motoristasRepository.criar(dados);
    }
}

module.exports = new MotoristasService();