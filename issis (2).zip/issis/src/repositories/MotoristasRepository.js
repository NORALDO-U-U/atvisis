const db = require('../config/database');

class MotoristasRepository {
    async buscarPorCpfOuCnh(nif_cpf, cnh) {
        // Query SQL limpa e parametrizada
        const query = 'SELECT * FROM motoristas WHERE nif_cpf = $1 OR cnh = $2';
        const { rows } = await db.query(query, [nif_cpf, cnh]);
        return rows[0];
    }

    async criar(motoristaData) {
        // Inserção com retorno da entidade criada
        const query = `
            INSERT INTO motoristas (nome, nif_cpf, cnh, telefone, email) 
            VALUES ($1, $2, $3, $4, $5) RETURNING *
        `;
        const values = [
            motoristaData.nome, 
            motoristaData.nif_cpf, 
            motoristaData.cnh, 
            motoristaData.telefone, 
            motoristaData.email
        ];
        const { rows } = await db.query(query, values);
        return rows[0];
    }
}

module.exports = new MotoristasRepository();